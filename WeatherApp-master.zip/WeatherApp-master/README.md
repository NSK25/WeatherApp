A NodeJs application developed using OpenWeatherMap API and IPInfo API. Given the city name, the application will return the temperature of that city. If any city name isn't provided the application predicts the location of the user accurately using IPInfo API and returns the weather of the day to the user.


<img width="566" alt="output" src="https://user-images.githubusercontent.com/10370182/29010910-ece0ffd6-7afc-11e7-9a72-18a4716e872f.png">
